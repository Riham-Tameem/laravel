

<?php $__env->startSection("title","Edit Category # $item->id"); ?>

<?php $__env->startSection("content"); ?>
<form method='post' action='<?php echo e(route("category.update",$item->id)); ?>'>
<?php echo csrf_field(); ?>
<?php echo method_field('put'); ?>
  <div class="mb-3">
    <label for="name" class="form-label">Category</label>
    <input type="text" value='<?php echo e(old('name',$item->name)); ?>' class="form-control" id="name" name='name'>
    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
  </div>
  <div class="mb-3 form-check">
    <input type='hidden' name='active' value='0'/>
    <input <?php echo e(old('active',$item->active)?"checked":""); ?> type="checkbox" class="form-check-input" value='1' name='active' id="active">
    <label class="form-check-label" for="active">Active</label>
  </div>
  <button type="submit" class="btn btn-primary">Update</button>
  <a href="<?php echo e(route('category.index')); ?>" class="btn btn-secondary">Cancel</a>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Basel Files\Fakhoora\advanced\resources\views/category/edit.blade.php ENDPATH**/ ?>