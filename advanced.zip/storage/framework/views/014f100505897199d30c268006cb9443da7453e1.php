

<?php $__env->startSection("title"," صلاحيات المستخدم "); ?>

<?php $__env->startSection("content"); ?>


<form class="form" action="<?php echo e(route('user.post-links',$item->id)); ?>" method="post" id="registrationForm"
    enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <ul class='list-unstyled'>
        <?php $__currentLoopData = $links->where('parent_id',0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
            $userHasLink = $item->links()->where('links.id',$topLink->id)->count();
        ?>
        <li>
            <label><input <?php echo e($userHasLink?"checked":""); ?> type='checkbox' name='links[]' value='<?php echo e($topLink->id); ?>'> <b><?php echo e($topLink->title); ?></b></label>
            <ul style='margin-right:10px' class='list-unstyled'>
            <?php $__currentLoopData = $links->where('parent_id',$topLink->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $userHasLink = $item->links()->where('links.id',$subLink->id)->count();
                ?>
                <li><label><input <?php echo e($userHasLink?"checked":""); ?>  type='checkbox' name='links[]' value='<?php echo e($subLink->id); ?>'> <?php echo e($subLink->title); ?></label></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    
    <div class="form-group">

        <br>
        <button class="btn btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i>
            حفظ</button>
        <a href='<?php echo e(route("user.index")); ?>' class="btn btn-default" type="reset"><i class="glyphicon glyphicon-repeat"></i> إلغاء </a>

    </div>
    <!--/row-->
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Basel Files\Fakhoora\advanced\resources\views/admin/user/links.blade.php ENDPATH**/ ?>