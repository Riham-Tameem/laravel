<?php if($errors->count()): ?>
    <div class='alert alert-danger mt-4'>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> 
<?php endif; ?>
<?php if(session()->get('msg')): ?>
    <div class='alert alert-info mt-4'><?php echo e(session()->get('msg')); ?></div> 
<?php endif; ?><?php /**PATH D:\Basel Files\Fakhoora\advanced\resources\views/layouts/msg.blade.php ENDPATH**/ ?>