
<?php $__env->startSection("aside"); ?>
<?php echo $__env->make("layouts.components.admin-menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("title",""); ?>
<?php $__env->startSection("title-side"); ?>


<a href="<?php echo e(route('appointment.create')); ?>" class="btn btn-accent m-btn m-btn--custom m-btn--pill m-btn--icon m-btn--air">
    <span>
        <i class="la la-plus"></i>
        <span>
            اضافة موعد جديد
        </span>
    </span>
</a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("content"); ?>

<div class="m-portlet m-portlet--mobile">
    <div class="m-portlet__body">
        <form class='row mb-3'>
            <div class='col-sm-8'>
                <input name='q' value='<?php echo e(request()->q); ?>' autofocus type="text" class='form-control'
                    placeholder="Enter your search ..." />
            </div>
            <div class='col-sm-1'>
                <button class='btn btn-primary' value='Search'><i class='fa fa-search'></i></button>
            </div>

        </form>

        <div id="m_table_1_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
            <div class="row">
                <div class="col-sm-12">
                   <?php if($items->count()>0): ?>
                    <table
                        class="table table-striped- table-bordered table-hover table-checkable dataTable no-footer dtr-inline"
                        id="m_table_1" role="grid" aria-describedby="m_table_1_info" style="width: 1150px;">
                        <thead>
                            <tr role="row">
                                <th>
                                    <label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
                                        <input type="checkbox" value="" class="m-group-checkable">
                                        <span></span>
                                    </label>
                                </th>
                                <th>اسم المريض</th>
                                <th>الطبيب</th>
                                <th>وقت الحجز                                </th>
                               
                                <th>اليوم </th>
                                <th>الملاحظات</th>
                                <th>الحالة</th>
                                <th>الاجراءات</th>

                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr role="row" class="odd">
                                <td width="5%" class=" dt-right" tabindex="0">
                                    <label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
                                        <input type="checkbox" value="" class="m-checkable">
                                        <span></span>
                                    </label>
                                </td>

                                <td><?php echo e($item->patient->name); ?></td>
                                <td><?php echo e($item->doctor->name??''); ?></td>
                                <td><?php echo e($item->from); ?> <?php echo e($item->to); ?></td>
                                
                                <td><?php echo e($item->day); ?></td>
                                <td><?php echo e($item->notes); ?></td>
                                <td> 
                                    <select data-aid='<?php echo e($item->id); ?>' name='status' class='ddlStatus form-control'>
                                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e($item->status_id==$s->id?"selected":""); ?> value='<?php echo e($s->id); ?>'><?php echo e($s->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    
                                </td>
                                

                                <td width="10%">
                                    <!--a href=''
                                        class="m-portlet__nav-link btn-primary m-btn m-btn--hover-brand m-btn--icon m-btn--icon-only m-btn--pill"
                                        title="تعديل">
                                        <i class="la la-edit"></i>
                                    </a-->

                                    <a href='<?php echo e(route("appointment.delete",$item->id)); ?>'
                                        class="btn-danger m-btn m-btn--hover-brand m-btn--icon m-btn--icon-only m-btn--pill"
                                        aria-expanded="true" title="حذف" onclick='return confirm("Are you sure?")'>
                                        <i class="flaticon-delete"></i>
                                    </a>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php echo e($items->links()); ?>

                <?php else: ?>
                    <div class='alert alert-info'><b>نأسف</b> !لا توجد نتائج </div>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
    <script>
        $(function(){
            $(".ddlStatus").change(function(){
                var aid = $(this).data('aid');
                var statusId = $(this).val();
                //alert("Appoinment ID: "+aid+", Status Id: " +statusId);
                $.get("<?php echo e(route('appointment.status')); ?>",{
                    "id":aid,
                    "status_id":statusId
                });
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Basel Files\Fakhoora\advanced\resources\views/admin/appointment/index.blade.php ENDPATH**/ ?>