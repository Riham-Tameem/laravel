

<?php $__env->startSection("title"," قائمة التخصصات  "); ?>

<?php $__env->startSection("content"); ?>

<a class='btn btn-success' href='<?php echo e(route("speciality.create")); ?>'>اضافة تخصص جديد   </a>


<?php if($items->count()): ?>
    <table class='table table-hover'>
        <thead>
        <tr>
            <th width='1%'>#</th>
            <th>الاسم </th>
            <th width='10%'>فعال</th>
            <th width='30%'>الخيارات </th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->active?'Active':'In Active'); ?></td>
                <td>
                    <form method='post' action="<?php echo e(route('speciality.destroy',$item->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <a href='<?php echo e(route("speciality.show",$item->id)); ?>' class='btn btn-info'>عرض</a>
                        <a href='<?php echo e(route("speciality.edit",$item->id)); ?>' class='btn btn-primary'>تعديل</a>

                        <input onclick='return confirm("Are you sure?")' type='submit' class='btn btn-danger' value='حذف'>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($items->links()); ?>

<?php else: ?>
    <div class='alert alert-info mt-4'>There is no items to show</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Basel Files\Fakhoora\advanced\resources\views/admin/speciality/index.blade.php ENDPATH**/ ?>