

<?php $__env->startSection("title","  اضافة تخصص "); ?>

<?php $__env->startSection("content"); ?>

<form method='post' action='<?php echo e(route("speciality.store")); ?>'>
    <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="name" class="form-label">التخصص</label>
    <input value='<?php echo e(old("name")); ?>' type="text" class="form-control" id="name" name='name'>

  </div>
  <div class="mb-3 form-check">
    <input type='hidden' name='active' value='0'/>
    <input <?php echo e(old("active")?"checked":""); ?> type="checkbox" name='active' value='1' class="form-check-input" id="active">
    <label class="form-check-label" for="active">Active </label>
  </div>
  <button type="submit" class="btn btn-primary">اضافة</button>
  <a href="<?php echo e(route('speciality.index')); ?>" class="btn btn-secondary">الغاء</a>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Basel Files\Fakhoora\advanced\resources\views/admin/speciality/create.blade.php ENDPATH**/ ?>