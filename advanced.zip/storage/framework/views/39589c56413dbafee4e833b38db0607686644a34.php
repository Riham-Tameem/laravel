

<?php $__env->startSection("title","Edit Post"); ?>

<?php $__env->startSection("content"); ?>

<form method='post' enctype='multipart/form-data' action='<?php echo e(route("post.update",$post->id)); ?>'>
    <?php echo csrf_field(); ?>
    <?php echo method_field("put"); ?>
  <div class="mb-3">
    <label for="name" class="form-label">Title</label>
    <input autofocus value='<?php echo e(old("title",$post->title)); ?>' type="text" class="form-control" id="title" name='title'>
    
  </div>
  <div class="mb-3">
    <label for="slug" class="form-label">Slug</label>
    <input  value='<?php echo e(old("slug",$post->slug)); ?>' type="text" class="form-control" id="slug" name='slug'>
    
  </div>
  
  <div class="mb-3">
    <label for="category_id" class="form-label">Category</label>
    <select class="form-control" id="category_id" name='category_id'>
      <option value=''>Select Category</option>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option <?php echo e(old('category_id',$post->category_id)==$category->id?"selected":""); ?> value='<?php echo e($category->id); ?>'><?php echo e($category->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="mb-3">
    <label for="summary" class="form-label">Summary</label>
    <textarea type="text" class="form-control" id="summary" name='summary'><?php echo e(old("summary",$post->summary)); ?></textarea>
    
  </div>
  <div class="mb-3">
    <label for="details" class="form-label">Details</label>
    <textarea type="text"  class="form-control" rows='10' id="details" name='details'><?php echo e(old("details",$post->details)); ?></textarea>
    
  </div>
  <div class="mb-3">
    <label for="image" class="form-label">Image</label>
    <input type="file" class="form-control" id="image" name='image'>
    <br>
    <img src='<?php echo e(asset("storage/images/".$post->image)); ?>' width='250' />
  </div>
  <div class="mb-3 form-check">
    <input type='hidden' name='published' value='0'/>
    <input id='published' <?php echo e(old("published",$post->published)?"checked":""); ?> type="checkbox" name='published' value='1' class="form-check-input" id="active">
    <label class="form-check-label" for="published">Published</label>
  </div>
  <button type="submit" class="btn btn-primary">Update</button>
  <a href="<?php echo e(route('post.index')); ?>" class="btn btn-secondary">Cancel</a>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Basel Files\Fakhoora\advanced\resources\views/post/edit.blade.php ENDPATH**/ ?>