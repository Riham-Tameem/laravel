

<?php $__env->startSection("title"," تعديل بيانات طبيب "); ?>

<?php $__env->startSection("content"); ?>


<form class="form" action="<?php echo e(route('doctor.update',$item->id)); ?>" method="post" id="registrationForm"
    enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field("put"); ?>
    <div class="row">

        <div class="col-sm-8">

            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="name">
                            <h5>الاسم</h5>
                        </label>
                        <input type="text" class="form-control" name="name" id="name" title="enter your  name if any."
                            value="<?php echo e(old('name',$item->name)); ?>">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="email">
                            <h5>الإيميل </h5>
                        </label>
                        <input type="email" class="form-control" name="email" id="email" title="enter your email."
                            value="<?php echo e(old('email',$item->user->email)); ?>">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="mobile">
                            <h5>الجوال</h5>
                        </label>
                        <input type="number" class="form-control" name="mobile" id="mobile" value="<?php echo e(old('mobile',$item->mobile)); ?>">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="city_id">
                            <h5>المدينة</h5>
                        </label>

                        <select class="form-select form-control" aria-label="Default select example" name="city_id"
                            id="city_id">
                            <option value="">اختر المدينة</option>
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e(old('city_id',$item->city_id)==$city->id?"selected":""); ?> value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="gender">
                            <h5>الجنس</h5>
                        </label>
                        <select class="form-select form-control" aria-label="Default select example" name="gender"
                            id="gender">
                            <option value="">اختر الجنس</option>

                            <option <?php echo e(old('gender',$item->gender)=='M'? 'selected': ''); ?> value="M">ذكر</option>
                            <option <?php echo e(old('gender',$item->gender)=='F'? 'selected': ''); ?> value="F"> أنثى </option>


                        </select>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="address">
                            <h5>العنوان</h5>
                        </label>
                        <input type="text" class="form-control" name="address" id="address" title="العنوان"
                            value="<?php echo e(old('address',$item->address)); ?>">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="description">
                            <h5>التخصص</h5>
                        </label>
                        <select class="form-control" name="speciality_id" id="cities_id"
                            >
                            <option value="">اختر التخصص</option>  
                            <?php $__currentLoopData = $specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(old('speciality_id',$item->speciality_id)==$speciality->id?'selected':''); ?>

                                value='<?php echo e($speciality->id); ?>'><?php echo e($speciality->name); ?> 
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="form-group">

                        <br>
                        <button class="btn btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i>
                            حفظ</button>
                        <a href='<?php echo e(route("doctor.index")); ?>' class="btn btn-default" type="reset"><i class="glyphicon glyphicon-repeat"></i> إلغاء </a>

                    </div>
                </div>
            </div>


        </div>
        <!--/col-9-->
        <div class="col-sm-4">
            <!--left col-->

            <div class="text-center">
                <img src="http://ssl.gstatic.com/accounts/ui/avatar_2x.png" name="img"
                    class="avatar  img-thumbnail rounded-circle" alt="avatar">
                <h4><?php echo e(auth()->user()->name); ?></h4>
                <h6>حمل صورة أخرى ...</h6>
                <input type="file" class="text-center center-block file-upload" name="imgFile">
            </div>


        </div>
        <!--/col-3-->
    </div>
    <!--/row-->
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Basel Files\Fakhoora\advanced\resources\views/admin/doctor/edit.blade.php ENDPATH**/ ?>