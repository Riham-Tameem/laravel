@extends("layouts.base")


@section("aside")
@include("layouts.components.patient-menu")
@endsection