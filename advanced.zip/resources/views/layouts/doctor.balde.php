@extends("layouts.base")


@section("aside")
@include("layouts.components.doctor-menu")
@endsection