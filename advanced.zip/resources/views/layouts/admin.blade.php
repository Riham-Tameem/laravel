@extends("layouts.base")


@section("aside")
@include("layouts.components.admin-menu")

@endsection
