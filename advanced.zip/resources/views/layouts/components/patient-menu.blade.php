<ul class="m-menu__nav  m-menu__nav--dropdown-submenu-arrow ">

    <li class="m-menu__item  m-menu__item--submenu" aria-haspopup="true" m-menu-submenu-toggle="hover">
        <a href="javascript:;" class="m-menu__link m-menu__toggle">
            <i class="m-menu__link-icon flaticon-layers"></i>
            <span class="m-menu__link-text">الزبون</span>
            <i class="m-menu__ver-arrow la la-angle-right">
            </i></a>
        <div class="m-menu__submenu "><span class="m-menu__arrow"></span>
            <ul class="m-menu__subnav">
                <li class="m-menu__item  m-menu__item--parent" aria-haspopup="true"><span class="m-menu__link"><span class="m-menu__link-text">Base</span></span></li>
            </ul>
        </div>
    </li>
</ul>
