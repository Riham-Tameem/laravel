<?php

return [
    'change_pass'   => 'تغيير كلمة المرور',
    'logout'   => 'تسجيل خروج',
];
