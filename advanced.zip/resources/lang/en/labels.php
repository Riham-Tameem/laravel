<?php

return [
    'change_pass'   => 'Change Password',
    'logout'   => 'Log out',
];
